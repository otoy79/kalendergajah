
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput1").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList1 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput2").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList2 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput3").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList3 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput4").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList4 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput5").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList5 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput6").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList6 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput7").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList7 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput8").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList8 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput9").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList9 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput10").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList10 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput11").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList11 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput12").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList12 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput13").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList13 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput14").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList14 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput15").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList15 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput16").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList16 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput17").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList17 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput18").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList18 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput19").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList19 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput20").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList20 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput21").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList21 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput22").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList22 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput23").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList23 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput24").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList24 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput25").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList25 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput26").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList26 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput27").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList27 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput28").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList28 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput29").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList29 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput30").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList30 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput31").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList31 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput32").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList32 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput33").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList33 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput34").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList34 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput35").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList35 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput36").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList36 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput37").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList37 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput38").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList38 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput39").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList39 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput40").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList40 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput41").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList41 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput42").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList42 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput43").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList43 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput44").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList44 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput45").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList45 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput46").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList46 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput47").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList47 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput48").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList48 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput49").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList49 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput50").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList50 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput51").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList51 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput52").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList52 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput53").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList53 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput54").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList54 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput55").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList55 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput56").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList56 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput57").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList57 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput58").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList58 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput59").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList59 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput60").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList60 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput61").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList61 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput62").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList62 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput63").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList63 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput64").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList64 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput65").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList65 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput66").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList66 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput67").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList67 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput68").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList68 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput69").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList69 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput70").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList70 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput71").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList71 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput72").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList72 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput73").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList73 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput74").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList74 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput75").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList75 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput76").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList76 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput77").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList77 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput78").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList78 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput79").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList79 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput80").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList80 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput81").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList81 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput82").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList82 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput83").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList83 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput84").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList84 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput85").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList85 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput86").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList86 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput87").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList87 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput88").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList88 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput89").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList89 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput90").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList90 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


$(document).ready(function(){
  $("#myInput91").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList91 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput92").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList92 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput93").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList93 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput94").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList94 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput95").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList95 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput96").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList96 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput97").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList97 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput98").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList98 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput99").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList99 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput100").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList100 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


$(document).ready(function(){
  $("#myInput100").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList100 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


$(document).ready(function(){
  $("#myInput101").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList101 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


$(document).ready(function(){
  $("#myInput102").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList102 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


$(document).ready(function(){
  $("#myInput103").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList103 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


$(document).ready(function(){
  $("#myInput104").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList104 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


$(document).ready(function(){
  $("#myInput105").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList105 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


$(document).ready(function(){
  $("#myInput106").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList106 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


$(document).ready(function(){
  $("#myInput107").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList107 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


$(document).ready(function(){
  $("#myInput108").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList108 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


$(document).ready(function(){
  $("#myInput109").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList109 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


$(document).ready(function(){
  $("#myInput110").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList110 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


$(document).ready(function(){
  $("#myInput111").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList111 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


$(document).ready(function(){
  $("#myInput112").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList112 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


$(document).ready(function(){
  $("#myInput113").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList113 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


$(document).ready(function(){
  $("#myInput114").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myList114 li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});





