
document.writeln("<a href=\"#S.1\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A1\')\"><srt1><img src=\'g/sname_1.png\' style=\'margin-top:-4px;float:right;padding-right:6px;width:63px;height:30px;\'></b></a> ");

document.writeln("<a href=\"#S.2\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A2\')\"><srt2><img src=\"g/sname_2.png\" style=\"margin-top:-4px;float:right;padding-right:6px;width:62px;height:30px;\"></b></a> ");

document.writeln("<a href=\"#S.3\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A3\')\"> <srt3><img src=\'g/sname_3.png\' style=\'margin-top:-3px;float:right;padding-right:6px;width:60px;height:30px;\'></b></a> ");

document.writeln("<a href=\"#S.4\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A4\')\"> <srt4><img src=\'g/sname_4.png\' style=\'margin-top:-3px;float:right;padding-right:6px;width:63px;height:30px;\'></b></a> ");

document.writeln("<a href=\"#S.5\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A5\')\"> <srt5><img src=\'g/sname_5.png\' style=\'margin-top:-3px;float:right;padding-right:6px;width:55px;height:30px;\'></b></a> ");
document.writeln(" ");
document.writeln(" <a href=\"#S.6\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A6\')\"><srt6><img src=\'g/sname_6.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:59px;height:30px;\'></b></a> ");
document.writeln(" ");
document.writeln(" <a href=\"#S.7\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A7\')\"><srt7><img src=\'g/sname_7.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:57px;height:30px;\'></b></a>");
document.writeln("");
document.writeln("<a href=\"#S.8\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A8\')\"><srt8><img src=\'g/sname_8.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:68px;height:30px;\'></b></a> ");
document.writeln(" ");
document.writeln(" <a href=\"#S.9\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A9\')\"><srt9><img src=\'g/sname_9.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:65px;height:30px;\'></b></a> ");
document.writeln(" ");
document.writeln(" <a href=\"#S.10\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A10\')\"><srt10><img src=\'g/sname_10.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:59px;height:30px;\'></b></a> ");
document.writeln(" ");
document.writeln("<a href=\"#S.11\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A11\')\"><srt11><img src=\'g/sname_11.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:45px;height:30px;\'></b></a> ");
document.writeln(" ");
document.writeln("<a href=\"#S.12\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A12\')\"><srt12><img src=\'g/sname_12.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:58px;height:30px;\'></b></a> ");
document.writeln(" ");
document.writeln(" <a href=\"#S.13\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A13\')\"><srt13><img src=\'g/sname_13.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:56px;height:30px;\'></b></a> ");
document.writeln("");
document.writeln(" <a href=\"#S.14\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A14\')\"><srt14><img src=\'g/sname_14.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:62px;height:30px;\'></b></a> ");
document.writeln("");
document.writeln(" <a href=\"#S.15\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A15\')\"><srt15><img src=\'g/sname_15.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:52px;height:30px;\'></b></a> ");
document.writeln("");
document.writeln(" <a href=\"#S.16\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A16\')\"><srt16><img src=\'g/sname_16.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:52px;height:30px;\'></b></a> ");
document.writeln("");
document.writeln(" <a href=\"#S.17\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A17\')\"><srt17><img src=\'g/sname_17.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:54px;height:30px;\'></b></a> ");
document.writeln("");
document.writeln(" <a href=\"#S.18\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A18\')\"><srt18><img src=\'g/sname_18.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:57px;height:30px;\'></b></a> ");
document.writeln("");
document.writeln(" <a href=\"#S.19\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A19\')\"><srt19><img src=\'g/sname_19.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:50px;height:30px;\'></b></a> ");
document.writeln("");
document.writeln(" <a href=\"#S.20\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A20\')\"><srt20><img src=\'g/sname_20.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:45px;height:30px;\'></b></a> ");
document.writeln("");
document.writeln(" <a href=\"#S.21\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A21\')\"><srt21><img src=\'g/sname_21.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:48px;height:30px;\'></b></a> ");
document.writeln("");
document.writeln(" <a href=\"#S.22\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A22\')\"><srt22><img src=\'g/sname_22.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:42px;height:30px;\'></b></a> ");
document.writeln("");
document.writeln(" <a href=\"#S.23\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A23\')\"><srt23><img src=\'g/sname_23.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:47px;height:30px;\'></b></a> ");
document.writeln("");
document.writeln(" <a href=\"#S.24\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A24\')\"><srt24><img src=\'g/sname_24.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:43px;height:30px;\'></b></a> ");
document.writeln("");
document.writeln(" <a href=\"#S.25\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A25\')\"><srt25><img src=\'g/sname_25.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:53px;height:30px;\'></b></a> ");
document.writeln("");
document.writeln("<a href=\"#S.26\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A26\')\"><srt26><img src=\'g/sname_26.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:53px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.27\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A27\')\"><srt27><img src=\'g/sname_27.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:46px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.28\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A28\')\"><srt28><img src=\'g/sname_28.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:52px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.29\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A29\')\"><srt29><img src=\'g/sname_29.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:59px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.30\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A30\')\"><srt30><img src=\'g/sname_30.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:47px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.31\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A31\')\"><srt31><img src=\'g/sname_31.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:49px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.32\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A32\')\"><srt32><img src=\'g/sname_32.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:51px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.33\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A33\')\"><srt33><img src=\'g/sname_33.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:55px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.34\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A34\')\"><srt34><img src=\'g/sname_34.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:48px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.35\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A35\')\"><srt35><img src=\'g/sname_35.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:45px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.36\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A36\')\"><srt36><img src=\'g/sname_36.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:52px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.37\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A37\')\"><srt37><img src=\'g/sname_37.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:58px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.38\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A38\')\"><srt38><img src=\'g/sname_38.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:48px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.39\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A39\')\"><srt39><img src=\'g/sname_39.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:58px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.40\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A40\')\"><srt40><img src=\'g/sname_40.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:62px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.41\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A41\')\"><srt41><img src=\'g/sname_41.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:62px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.42\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A42\')\"><srt42><img src=\'g/sname_42.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:60px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.43\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A43\')\"><srt43><img src=\'g/sname_43.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:63px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.44\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A44\')\"><srt44><img src=\'g/sname_44.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:60px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.45\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A45\')\"><srt45><img src=\'g/sname_45.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:58px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.46\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A46\')\"><srt46><img src=\'g/sname_46.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:58px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.47\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A47\')\"><srt47><img src=\'g/sname_47.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:56px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.48\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A48\')\"><srt48><img src=\'g/sname_48.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:51px;height:30px;\'></b></a>");
document.writeln(" ");
document.writeln("<a href=\"#S.49\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A49\')\"><srt49><img src=\'g/sname_49.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:57px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.50\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A50\')\"><srt50><img src=\'g/sname_50.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:45px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.51\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A51\')\"><srt51><img src=\'g/sname_51.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:65px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.52\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A52\')\"><srt52><img src=\'g/sname_52.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:57px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.53\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A53\')\"><srt53><img src=\'g/sname_53.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:53px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.54\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A54\')\"><srt54><img src=\'g/sname_54.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:55px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.55\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A55\')\"><srt55><img src=\'g/sname_55.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:66px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.56\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A56\')\"><srt56><img src=\'g/sname_56.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:70px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.57\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A57\')\"><srt57><img src=\'g/sname_57.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:65px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.58\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A58\')\"><srt58><img src=\'g/sname_58.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:69px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.59\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A59\')\"><srt59><img src=\'g/sname_59.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:59px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.60\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A60\')\"><srt60><img src=\'g/sname_60.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:67px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.61\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A61\')\"><srt61><img src=\'g/sname_61.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:58px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.62\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A62\')\"><srt62><img src=\'g/sname_62.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:65px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.63\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A63\')\"><srt63><img src=\'g/sname_63.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:70px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.64\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A64\')\"><srt64><img src=\'g/sname_64.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:68px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.65\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A65\')\"><srt65><img src=\'g/sname_65.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:68px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.66\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A66\')\"><srt66><img src=\'g/sname_66.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:70px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.67\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A67\')\"><srt67><img src=\'g/sname_67.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:60px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.68\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A68\')\"><srt68><img src=\'g/sname_68.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:57px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.69\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A69\')\"><srt69><img src=\'g/sname_69.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:70px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.70\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A70\')\"><srt70><img src=\'g/sname_70.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:69px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.71\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A71\')\"><srt71><img src=\'g/sname_71.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:58px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.72\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A72\')\"><srt72><img src=\'g/sname_72.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:56px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.73\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A73\')\"><srt73><img src=\'g/sname_73.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:69px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.74\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A74\')\"><srt74><img src=\'g/sname_74.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:65px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.75\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A75\')\"><srt75><img src=\'g/sname_75.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:63px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.76\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A76\')\"><srt76><img src=\'g/sname_76.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:63px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.77\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A77\')\"><srt77><img src=\'g/sname_77.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:63px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.78\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A78\')\"><srt78><img src=\'g/sname_78.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:63px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.79\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A79\')\"><srt79><img src=\'g/sname_79.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:63px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.80\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A80\')\"><srt80><img src=\'g/sname_80.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:59px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.81\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A81\')\"><srt81><img src=\'g/sname_81.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:63px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.82\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A82\')\"><srt82><img src=\'g/sname_82.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:68px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.83\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A83\')\"><srt83><img src=\'g/sname_83.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:68px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.84\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A84\')\"><srt84><img src=\'g/sname_84.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:67px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.85\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A85\')\"><srt85><img src=\'g/sname_85.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:67px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.86\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A86\')\"><srt86><img src=\'g/sname_86.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:67px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.87\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A87\')\"><srt87><img src=\'g/sname_87.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:64px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.88\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A88\')\"><srt88><img src=\'g/sname_88.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:68px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.89\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A89\')\"><srt89><img src=\'g/sname_89.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:64px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.90\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A90\')\"><srt90><img src=\'g/sname_90.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:66px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.91\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A91\')\"><srt91><img src=\'g/sname_91.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:66px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.92\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A92\')\"><srt92><img src=\'g/sname_92.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:60px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.93\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A93\')\"><srt93><img src=\'g/sname_93.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:66px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.94\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A94\')\"><srt94><img src=\'g/sname_94.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:66px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.95\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A95\')\"><srt95><img src=\'g/sname_95.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:63px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.96\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A96\')\"><srt96><img src=\'g/sname_96.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:66px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.97\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A97\')\"><srt97><img src=\'g/sname_97.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:60px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.98\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A98\')\"><srt98><img src=\'g/sname_98.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:66px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.99\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A99\')\"><srt99><img src=\'g/sname_99.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:68px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.100\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A100\')\"><srt100><img src=\'g/sname_100.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:55px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.101\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A101\')\"><srt101><img src=\'g/sname_101.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:62px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.102\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A102\')\"><srt102><img src=\'g/sname_102.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:58px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.103\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A103\')\"><srt103><img src=\'g/sname_103.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:57px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.104\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A104\')\"><srt104><img src=\'g/sname_104.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:59px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.105\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A105\')\"><srt105><img src=\'g/sname_105.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:56px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.106\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A106\')\"><srt106><img src=\'g/sname_106.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:55px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.107\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A107\')\"><srt107><img src=\'g/sname_107.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:60px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.108\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A108\')\"><srt108><img src=\'g/sname_108.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:58px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.109\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A109\')\"><srt109><img src=\'g/sname_109.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:61px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.110\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A110\')\"><srt110><img src=\'g/sname_110.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:56px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.111\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A111\')\"><srt111><img src=\'g/sname_111.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:58px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.112\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A112\')\"><srt112><img src=\'g/sname_112.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:59px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.113\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A113\')\"><srt113><img src=\'g/sname_113.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:57px;height:30px;\'></b></a>");

document.writeln(" ");
document.writeln("<a href=\"#S.114\" onClick=\"return noHistory(this);\" class=\"button\"><b onclick=\"openCity(event, \'A114\')\"><srt114><img src=\'g/sname_114.png\' style=\'margin-top:-3px;float:right;padding-right:7px;width:59px;height:30px;\'></b></a>");
